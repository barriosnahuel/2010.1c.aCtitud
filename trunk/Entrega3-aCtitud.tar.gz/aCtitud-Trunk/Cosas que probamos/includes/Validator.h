/*
 * Validator.h
 *
 *  Created on: Apr 23, 2010
 *      Author: Barrios, Nahuel.
 */

#ifndef VALIDATOR_H_
#define VALIDATOR_H_

class Validator {
public:
	Validator();
	virtual ~Validator();

	bool validameEsta(int i);
};

#endif /* VALIDATOR_H_ */
